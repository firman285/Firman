package com.bmi.bumimutiaraindah

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.bmi.bumimutiaraindah.data.FirebaseRepository
import kotlinx.coroutines.launch

private val Green=Color(0xFF087A52)
private val Light=Color(0xFFE9F6F0)

class MainActivity:ComponentActivity(){
    override fun onCreate(savedInstanceState:Bundle?){
        super.onCreate(savedInstanceState)
        setContent{BMIApp()}
    }
}

@Composable
fun BMIApp(){
    val repo=remember{FirebaseRepository()}
    var logged by remember{mutableStateOf(repo.isLoggedIn())}
    var register by remember{mutableStateOf(false)}
    MaterialTheme(colorScheme=lightColorScheme(primary=Green)){
        if(!logged){
            AuthScreen(repo,register,{register=!register},{logged=true})
        }else{
            MainScreen(repo){logged=false}
        }
    }
}

@Composable
fun AuthScreen(repo:FirebaseRepository,register:Boolean,toggle:()->Unit,onSuccess:()->Unit){
    val scope=rememberCoroutineScope()
    var name by remember{mutableStateOf("")}
    var email by remember{mutableStateOf("")}
    var pass by remember{mutableStateOf("")}
    var error by remember{mutableStateOf("")}
    var loading by remember{mutableStateOf(false)}
    Column(Modifier.fillMaxSize().padding(24.dp),verticalArrangement=Arrangement.Center){
        Text("BMI",fontSize=40.sp,fontWeight=FontWeight.Bold,color=Green)
        Text("Bumi Mutiara Indah",fontSize=20.sp)
        Spacer(Modifier.height(24.dp))
        if(register) OutlinedTextField(name,{name=it},label={Text("Nama")},modifier=Modifier.fillMaxWidth(),singleLine=true)
        Spacer(Modifier.height(8.dp))
        OutlinedTextField(email,{email=it},label={Text("Email")},modifier=Modifier.fillMaxWidth(),singleLine=true)
        Spacer(Modifier.height(8.dp))
        OutlinedTextField(pass,{pass=it},label={Text("Password")},modifier=Modifier.fillMaxWidth(),singleLine=true,visualTransformation=PasswordVisualTransformation())
        Spacer(Modifier.height(12.dp))
        if(error.isNotBlank()) Text(error,color=MaterialTheme.colorScheme.error)
        Button(enabled=!loading&&email.isNotBlank()&&pass.length>=6&&(!register||name.isNotBlank()),onClick={
            scope.launch{
                loading=true
                val r=if(register) repo.register(name,email,pass) else repo.login(email,pass)
                loading=false
                r.onSuccess{onSuccess()}.onFailure{error=it.message ?: "Terjadi kesalahan"}
            }
        },modifier=Modifier.fillMaxWidth()){Text(if(loading)"Memproses..." else if(register)"Daftar" else "Masuk")}
        TextButton(toggle,Modifier.align(Alignment.CenterHorizontally)){Text(if(register)"Sudah punya akun? Masuk" else "Belum punya akun? Daftar")}
    }
}

@Composable
fun MainScreen(repo:FirebaseRepository,logout:()->Unit){
    var page by remember{mutableStateOf("home")}
    var showComplaint by remember{mutableStateOf(false)}
    Scaffold(bottomBar={
        NavigationBar{
            Item("Beranda",Icons.Default.Home,page=="home"){page="home"}
            Item("Layanan",Icons.Default.Description,page=="service"){page="service"}
            Item("Marketing",Icons.Default.HomeWork,page=="marketing"){page="marketing"}
            Item("Pengaduan",Icons.Default.ReportProblem,page=="complaint"){page="complaint"}
            Item("Profil",Icons.Default.Person,page=="profile"){page="profile"}
        }
    }){p->Box(Modifier.fillMaxSize().padding(p)){
        when(page){
            "home"->Home{page=it}
            "service"->SimplePage("Pelayanan",listOf("Surat pengantar","Administrasi warga","Permintaan layanan","Jadwal pelayanan"))
            "marketing"->SimplePage("Marketing",listOf("Unit A-01 • Tipe 36 • Tersedia","Unit A-02 • Tipe 45 • Tersedia","Unit B-10 • Tipe 54 • Terjual"))
            "complaint"->ComplaintPage(repo,{showComplaint=true})
            "profile"->ProfilePage(repo,logout)
        }
    }}
    if(showComplaint) ComplaintDialog(repo){showComplaint=false}
}

@Composable fun Item(t:String,i:androidx.compose.ui.graphics.vector.ImageVector,s:Boolean,c:()->Unit)=NavigationBarItem(s,c,icon={Icon(i,null)},label={Text(t,fontSize=10.sp)})
@Composable fun Home(go:(String)->Unit){LazyColumn(Modifier.fillMaxSize(),contentPadding=PaddingValues(16.dp),verticalArrangement=Arrangement.spacedBy(12.dp)){item{Text("BMI",fontSize=32.sp,fontWeight=FontWeight.Bold,color=Green);Text("Bumi Mutiara Indah",color=Color.Gray)};item{Card(colors=CardDefaults.cardColors(Green),shape=RoundedCornerShape(20.dp)){Column(Modifier.padding(20.dp)){Text("Selamat Datang 👋",color=Color.White,fontSize=23.sp,fontWeight=FontWeight.Bold);Text("Aplikasi layanan warga BMI.",color=Color.White)}}};item{Text("Layanan",fontWeight=FontWeight.Bold,fontSize=19.sp)};listOf("Pelayanan" to "service","Marketing" to "marketing","Pengaduan" to "complaint").forEach{(t,p)->item{Card(Modifier.fillMaxWidth(),shape=RoundedCornerShape(15.dp)){Row(Modifier.padding(17.dp),verticalAlignment=Alignment.CenterVertically){Text(t,fontWeight=FontWeight.Bold);Spacer(Modifier.weight(1f));Text("Buka",color=Green,fontWeight=FontWeight.Bold);IconButton{go(p)}}}}}}}
@Composable fun SimplePage(title:String,items:List<String>){LazyColumn(Modifier.fillMaxSize(),contentPadding=PaddingValues(16.dp),verticalArrangement=Arrangement.spacedBy(10.dp)){item{Text(title,fontSize=28.sp,fontWeight=FontWeight.Bold);Text("Informasi BMI",color=Color.Gray)};items.forEach{x->item{Card(Modifier.fillMaxWidth(),shape=RoundedCornerShape(15.dp)){Row(Modifier.padding(16.dp)){Text(x);Spacer(Modifier.weight(1f));Icon(Icons.Default.ChevronRight,null)}}}}}}
@Composable fun ComplaintPage(repo:FirebaseRepository,add:()->Unit){var loading by remember{mutableStateOf(false)};var data by remember{mutableStateOf<List<com.bmi.bumimutiaraindah.data.Complaint>>(emptyList())};val scope=rememberCoroutineScope();LaunchedEffect(Unit){loading=true;repo.getMyComplaints().onSuccess{data=it};loading=false};Scaffold(floatingActionButton={FloatingActionButton(add,containerColor=Green,contentColor=Color.White){Icon(Icons.Default.Add,null)}}){p->LazyColumn(Modifier.fillMaxSize().padding(p),contentPadding=PaddingValues(16.dp),verticalArrangement=Arrangement.spacedBy(10.dp)){item{Text("Pengaduan",fontSize=28.sp,fontWeight=FontWeight.Bold);Text("Laporan tersimpan online.",color=Color.Gray)};if(loading)item{CircularProgressIndicator()};if(!loading&&data.isEmpty())item{Text("Belum ada laporan.")};data.forEach{c->item{Card{Column(Modifier.padding(16.dp)){Text(c.ticket,color=Green,fontWeight=FontWeight.Bold);Text(c.title,fontWeight=FontWeight.Bold);Text("${c.category} • ${c.location}",color=Color.Gray);Text("Status: ${c.status}",color=Green)}}}}}}}
@Composable fun ComplaintDialog(repo:FirebaseRepository,close:()->Unit){var cat by remember{mutableStateOf("Infrastruktur")};var title by remember{mutableStateOf("")};var loc by remember{mutableStateOf("")};var desc by remember{mutableStateOf("")};var error by remember{mutableStateOf("")};val scope=rememberCoroutineScope();AlertDialog(onDismissRequest=close,title={Text("Buat Pengaduan")},text={Column{listOf("Infrastruktur","Kebersihan","Keamanan").forEach{x->FilterChip(cat==x,{cat=x},{Text(x)})};OutlinedTextField(title,{title=it},label={Text("Judul")});OutlinedTextField(loc,{loc=it},label={Text("Lokasi")});OutlinedTextField(desc,{desc=it},label={Text("Keterangan")});if(error.isNotBlank())Text(error,color=Color.Red)}},confirmButton={Button(title.isNotBlank()&&loc.isNotBlank(),{scope.launch{repo.saveComplaint(cat,title,loc,desc).onSuccess{close()}.onFailure{error=it.message?:"Gagal"}}}){Text("Kirim")}},dismissButton={TextButton(close){Text("Batal")}})}
@Composable fun ProfilePage(repo:FirebaseRepository,logout:()->Unit){LazyColumn(Modifier.fillMaxSize(),contentPadding=PaddingValues(16.dp),verticalArrangement=Arrangement.spacedBy(12.dp)){item{Text("Profil",fontSize=28.sp,fontWeight=FontWeight.Bold)};item{Card{Column(Modifier.padding(20.dp)){Icon(Icons.Default.AccountCircle,null,tint=Green,modifier=Modifier.size(60.dp));Text(repo.currentUid()?: "UID",fontWeight=FontWeight.Bold);Text("Akun warga",color=Color.Gray)}}};item{Button(logout,Modifier.fillMaxWidth()){Text("Keluar")}}}}
