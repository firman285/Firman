package com.bmi.bumimutiaraindah.data

import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore
import kotlinx.coroutines.tasks.await

class FirebaseRepository(
    private val auth: FirebaseAuth = FirebaseAuth.getInstance(),
    private val db: FirebaseFirestore = FirebaseFirestore.getInstance()
) {
    suspend fun register(name:String,email:String,password:String):Result<Unit> = runCatching {
        val result=auth.createUserWithEmailAndPassword(email,password).await()
        val uid=result.user?.uid ?: error("UID tidak tersedia")
        db.collection("users").document(uid).set(
            UserProfile(uid,name,email,"","warga")
        ).await()
    }

    suspend fun login(email:String,password:String):Result<Unit> = runCatching {
        auth.signInWithEmailAndPassword(email,password).await()
    }

    fun logout(){ auth.signOut() }
    fun currentUid():String?=auth.currentUser?.uid
    fun isLoggedIn():Boolean=auth.currentUser!=null

    suspend fun saveComplaint(
        category:String,title:String,location:String,description:String
    ):Result<String> = runCatching {
        val uid=currentUid() ?: error("Silakan login")
        val ref=db.collection("complaints").document()
        val ticket="BMI-"+System.currentTimeMillis().toString().takeLast(7)
        ref.set(
            Complaint(ref.id,uid,ticket,category,title,location,description)
        ).await()
        ticket
    }

    suspend fun getMyComplaints():Result<List<Complaint>> = runCatching {
        val uid=currentUid() ?: error("Silakan login")
        db.collection("complaints").whereEqualTo("uid",uid).get().await()
            .documents.mapNotNull { it.toObject(Complaint::class.java) }
            .sortedByDescending { it.createdAt }
    }
}
