package com.bmi.bumimutiaraindah.data

data class UserProfile(
    val uid:String="",
    val name:String="",
    val email:String="",
    val address:String="",
    val role:String="warga"
)

data class Complaint(
    val id:String="",
    val uid:String="",
    val ticket:String="",
    val category:String="",
    val title:String="",
    val location:String="",
    val description:String="",
    val status:String="Diterima",
    val createdAt:Long=System.currentTimeMillis()
)
