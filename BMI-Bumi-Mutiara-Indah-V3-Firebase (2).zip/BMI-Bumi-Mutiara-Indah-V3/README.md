# BMI – Bumi Mutiara Indah V3

Fondasi aplikasi online nyata menggunakan Firebase.

## Yang sudah disiapkan
- Login & daftar akun email/password
- Logout
- Firebase Authentication
- Cloud Firestore
- Repository untuk profil warga dan pengaduan
- Nomor tiket pengaduan
- Status pengaduan
- Struktur role warga/admin
- Beranda online
- Pelayanan
- Marketing
- Iuran
- Berita
- Keamanan
- Profil
- Admin dashboard dasar

## PENTING
`google-services.json` TIDAK disertakan karena file tersebut harus dibuat dari Firebase project milik pemilik aplikasi.

Langkah:
1. Buka Firebase Console.
2. Buat project baru, misalnya "BMI Bumi Mutiara Indah".
3. Tambahkan Android App dengan package:
   `com.bmi.bumimutiaraindah`
4. Download `google-services.json`.
5. Masukkan file tersebut ke:
   `app/google-services.json`
6. Di Firebase Authentication aktifkan Email/Password.
7. Buat Cloud Firestore.
8. Jalankan Android Studio > Sync Project > Run.

Dokumentasi resmi:
https://firebase.google.com/docs/android/setup
